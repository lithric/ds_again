echo "3 * (2 + 4/105)
a = 3 * (2 + 4/105)
a
a - 4/35
b = a - 4/35
b
#" | ./project2
echo "abc = 3 * (2 + 4/105)
#" | ./project2 -t