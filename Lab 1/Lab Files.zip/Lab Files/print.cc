#include "lab1.h"

void printData(int data[],int nItems) {
  int i;

  for (i=0;i<nItems;i++)
    cout << data[i] << endl;
}
